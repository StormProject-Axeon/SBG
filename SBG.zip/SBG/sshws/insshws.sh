#!/bin/bash
#apt-get install nodejs -y >/dev/null 2>&1

mv /root/SBG/sshws/sbg.py /usr/local/bin/sbg
chmod +x /usr/local/bin/sbg

# Installing Service
cat > /etc/systemd/system/ws.service << END
[Unit]
Description=Python Proxy Mod By Jerry
Documentation=https://t.me/Jerry_SBG
After=network.target nss-lookup.target

[Service]
Type=simple
User=root
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
NoNewPrivileges=true
ExecStart=/usr/bin/python3 -O /usr/local/bin/sbg 701
Restart=on-failure

[Install]
WantedBy=multi-user.target
END

#mv /root/SBG/sshws/ws.js /usr/local/bin/ws.js
#chmod +x /usr/local/bin/ws.js

#cat > /etc/systemd/system/ws.service << END
#[Unit]
#Description=Websocket Service 
#Documentation=https://t.me/Jerry_SBG
#After=network.target nss-lookup.target

#[Service]
#Type=simple
#User=root
#CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
#AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
#NoNewPrivileges=true
#ExecStart=/usr/bin/node --expose-gc /usr/local/bin/ws.js -dhost 127.0.0.1 -dport 143 -mport 701
#Restart=on-failure

#[Install]
#WantedBy=multi-user.target
#END

#mv /root/SBG/sshws/ws.py /usr/local/bin/ws-stunnel
#chmod +x /usr/local/bin/ws-stunnel

# Installing Service
#cat > /etc/systemd/system/ws-stunnel.service << END
#[Unit]
#Description=Python Proxy Mod By Jerry
#Documentation=https://t.me/Jerry_SBG
#After=network.target nss-lookup.target

#[Service]
#Type=simple
#User=root
#CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
#AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
#NoNewPrivileges=true
#ExecStart=/usr/bin/python3 -O /usr/local/bin/ws-stunnel 700
#Restart=on-failure

#[Install]
#WantedBy=multi-user.target
#END

#mv /root/SBG/sshws/wssl.js /usr/local/bin/wssl.js
#chmod +x /usr/local/bin/wssl.js

#mv /root/SBG/sshws/ws-js /etc/systemd/system/ws-stunnel.service

# Installing Service
#cat > /etc/systemd/system/ws-stunnel.service << END
#[Unit]
#Description=Websocket Service 
#Documentation=https://t.me/Jerry_SBG
#After=network.target nss-lookup.target

#[Service]
#Type=simple
#User=root
#CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
#AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
#NoNewPrivileges=true
#ExecStart=/usr/bin/node --expose-gc /usr/local/bin/wssl.js -dhost 127.0.0.1 -dport 143 -mport 700
#Restart=on-failure

#[Install]
#WantedBy=multi-user.target
#END

systemctl daemon-reload
#systemctl enable ws-ovpn.service
#systemctl start ws-ovpn.service
#systemctl restart ws-ovpn.service
systemctl enable ws.service
systemctl start ws.service
systemctl restart ws.service
#systemctl enable ws-stunnel.service
#systemctl start ws-stunnel.service
#systemctl restart ws-stunnel.service