#!/bin/bash

printf "q\n" | rclone config
mv /root/SBG/install/rclone.conf /root/.config/rclone/rclone.conf
git clone  https://github.com/casper9/wondershaper.git
cd wondershaper
make install
cd
rm -rf wondershaper
cd /usr/local/bin
mv /root/SBG/install/cleaner.sh /usr/local/bin/cleaner
mv /root/SBG/install/autocpu.sh /usr/local/bin/autocpu
cd

#if [ ! -f "/etc/cron.d/cleaner" ]; then
rm -rf /etc/cron.d/cleaner
cat> /etc/cron.d/cleaner << END
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
*/10 * * * * root bash /usr/local/bin/cleaner
END
#fi

#if [ ! -f "/etc/cron.d/cleaner" ]; then
rm -rf /etc/cron.d/tmp
cat> /etc/cron.d/tmp << END
*/1 * * * * root rm -rf /tmp/tmp.*
END
#fi

#if [ ! -f "/etc/cron.d/autocpu" ]; then
rm -rf /etc/cron.d/autocpu
cat> /etc/cron.d/autocpu << END
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
*/59 */23 */2 * * root bash /usr/local/bin/autocpu
END
#fi

#if [ ! -f "/etc/cron.d/xp_otm" ]; then
rm -rf /etc/cron.d/xp_otm
cat> /etc/cron.d/xp_otm << END
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
0 18 * * * root bash /usr/local/sbin/xp
END
#fi

#if [ ! -f "/etc/cron.d/bckp_otm" ]; then
rm -rf /etc/cron.d/bckp_otm
cat> /etc/cron.d/bckp_otm << END
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
59 23 * * * root bash /usr/local/sbin/bottelegram
END
#fi

#if [ ! -f "/etc/cron.d/tendang" ]; then
rm -rf /etc/cron.d/tendang
cat> /etc/cron.d/tendang << END
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
*/5 * * * * root bash /usr/local/sbin/tendang
END
#fi

#if [ ! -f "/etc/cron.d/xraylimit" ]; then
rm -rf /etc/cron.d/xraylimit
cat> /etc/cron.d/xraylimit << END
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
*/5 * * * * root bash /usr/local/sbin/xraylimit
END
#fi
#secho "*/30 * * * * sudo systemctl restart xray" >>/var/spool/cron/crontabs/root
service cron restart >/dev/null 2>&1
service cron reload >/dev/null 2>&1
service cron start >/dev/null 2>&1

# > Pasang Limit

#wget "https://raw.githubusercontent.com/JerrySBG/SBG2/main/bin/limit.sh" >/dev/null 2>&1

#chmod +x limit.sh && bash limit.sh >/dev/null 2>&1
    
rm -f /root/SBG/install/set-br.sh
#rm -f /root/limit.sh
