#!/bin/bash
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
colornow=$(cat /etc/rmbl/theme/color.conf)
NC="\e[0m"
RED="\033[0;31m"
COLOR1="$(cat /etc/rmbl/theme/$colornow | grep -w "TEXT" | cut -d: -f2|sed 's/ //g')"
COLBG1="$(cat /etc/rmbl/theme/$colornow | grep -w "BG" | cut -d: -f2|sed 's/ //g')"
WH='\033[1;37m'
echo "$month_tx $month_txv" > /etc/usage2
xray2=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
if [[ $xray2 == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart xray
systemctl start xray
fi
ssl=$(systemctl status stunnel4 | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
if [[ $ssl == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart stunnel4
systemctl start stunnel4
fi
haproxy=$(systemctl status haproxy | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
if [[ $haproxy == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart haproxy
systemctl start haproxy
fi
udpcustom=$(systemctl status udp-custom | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
if [[ $udpcustom == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart udp-custom
fi
zivpn=$(systemctl status zivpn | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
if [[ $zivpn == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart zivpn
fi
udpmod=$(systemctl status udpmod | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
if [[ $udpmod == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart udpmod
fi
nginx2=$(systemctl status nginx | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
if [[ $nginx2 == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart nginx
fi
#nginx3=$( systemctl status nginx | grep "inactive" | awk '{print $2}' | sed 's/(//g' | sed 's/)//g' )
#if [[ $nginx3 == "running" ]]; then
#echo -ne
#else
#systemctl daemon-reload
#systemctl restart nginx
#systemctl start nginx
#fi
#cd
if [[ -e /usr/bin/kyt ]]; then
kyt=$(systemctl status kyt | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
if [[ $kyt == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart kyt
systemctl start kyt
fi
if [[ -e /usr/bin/kyt ]]; then
kyt2=$(systemctl status kyt | grep failed  | awk '{print $2}' | sed 's/(//g' | sed 's/)//g')
if [[ $kyt2 == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart kyt
systemctl start kyt
fi
key=$(systemctl status kyt | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
if [[ $key == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart kyt
systemctl start kyt
fi
cd
dropbear=$(systemctl status ws | grep "Active" | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
if [[ $dropbear == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart ws
systemctl start ws
systemctl restart haproxy
systemctl start haproxy
systemctl restart nginx
systemctl start nginx
fi
#stunnel=$(systemctl status ws-stunnel | grep "Active" | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
#if [[ $stunnel == "running" ]]; then
#echo -ne
#else
#systemctl daemon-reload
#systemctl restart ws-stunnel
#systemctl start ws-stunnel
#systemctl restart haproxy
#systemctl start haproxy
#systemctl restart nginx
#systemctl start nginx
#fi
#xrray=$(systemctl status xray | grep "error" | awk '{print $3}' | sed 's/(//g' | sed 's/)//g')
#if [[ $xrray == "0" ]]; then
#echo -ne
#else
#systemctl daemon-reload
#systemctl restart xray
#systemctl restart nginx
#fi
xrray2=$(systemctl status xray | grep "inactive" | awk '{print $2}' | sed 's/(//g' | sed 's/)//g')
if [[ $xrray2 == "running" ]]; then
echo -ne
else
systemctl daemon-reload
systemctl restart xray
systemctl restart nginx
fi