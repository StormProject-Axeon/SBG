#!/bin/bash

clear
#data=(`find /var/log/ -name '*.log' | find /var/log/nginx -name '*.log' | find /var/log/squid -name '*.log' | find /var/log/stunnel4 -name '*.log' | find /var/log/trojan-go -name '*.log' | find /var/log/xray -name '*.log'`);
data=(`find /tmp/ -name 'tmp.*' -delete | find /var/log/ -name 'tmp*' | find /var/log/nginx -name '*.log' | find /var/log/squid -name '*.log' | find /var/log/stunnel4 -name '*.log' | find /var/log/trojan-go -name '*.log' | find /var/log/xray -name '*.log'`);
for log in "${data[@]}"
do
echo "$log clear"
echo > $log
done
data=(`find /var/log/ -name '*.err'`);
for log in "${data[@]}"
do
echo "$log clear"
echo > $log
done
data=(`find /var/log/ -name 'mail.*'`);
for log in "${data[@]}"
do
echo "$log clear"
echo > $log
done
echo > /var/log/syslog
echo > /var/log/btmp
echo > /var/log/messages
echo > /var/log/debug
bcc=`date`
echo ""
echo "Borrado de LOGS con Exito $bcc"
sleep 0.5
clear
echo ""
