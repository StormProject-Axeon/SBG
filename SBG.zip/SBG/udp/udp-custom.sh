#!/bin/bash
cd
rm -rf /etc/udp
mkdir -p /etc/udp

# change to time UTC-6
echo "ZONA DE HORARIO A MEXICO"
ln -fs /usr/share/zoneinfo/America/Mexico_City /etc/localtime

# install udp-custom
echo downloading udp-custom
mv /root/SBG/udp/udp-amd64.bin /etc/udp/udp-custom
chmod +x /etc/udp/udp-custom

echo downloading default config
mv /root/SBG/udp/config.json /etc/udp/config.json
chmod 644 /etc/udp/config.json

if [ -z "$1" ]; then
cat <<EOF > /etc/systemd/system/udp-custom.service
[Unit]
Description=UDP Custom by JerrySBG

[Service]
User=root
Type=simple
ExecStart=/etc/udp/udp-custom --config /etc/udp/config.json
WorkingDirectory=/etc/udp/
Restart=always
RestartSec=2s

[Install]
WantedBy=default.target
EOF
else
cat <<EOF > /etc/systemd/system/udp-custom.service
[Unit]
Description=UDP Custom by JerrySBG

[Service]
User=root
Type=simple
ExecStart=/etc/udp/udp-custom server --config /etc/udp/config.json
WorkingDirectory=/etc/udp/
Restart=always
RestartSec=2s

[Install]
WantedBy=default.target
EOF
fi

sed -i 's/36712/36715/g' /etc/udp/config.json

echo "UDP CUSTOM INSTALADO"
systemctl daemon-reload
systemctl start udp-custom &>/dev/null

echo enable service udp-custom
systemctl enable udp-custom &>/dev/null

echo restart service udp-custom
systemctl restart udp-custom &>/dev/null
systemctl daemon-reload
#iptables -t nat -D PREROUTING -i venet0 -p udp --dport 40000:65535 -j DNAT --to-destination :36715
iptables-save > /etc/iptables/rules.v4
#iptables -t nat -A PREROUTING -i $(ip -4 route ls|grep default|grep -Po '(?<=dev )(\S+)'|head -1) -p udp --dport 40000:65535 -j DNAT --to-destination :36715
#ufw allow 40000:65535/udp
#ufw allow 36715/udp
sleep 1
clear
#read -p "Presione [Enter] para Continuar"
#rm -f /root/udp-custom.sh
#menu