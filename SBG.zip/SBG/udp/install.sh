#!/bin/bash
NC='\e[0m'
colornow=$(cat /etc/rmbl/theme/color.conf)
export NC="\e[0m"
export COLOR1="$(cat /etc/rmbl/theme/$colornow | grep -w "TEXT" | cut -d: -f2|sed 's/ //g')"
rm -rf $(pwd)/$0
JS=$(cat /usr/bin/vendor_codes)
if [[ -e /etc/xray/domain ]]; then
domain=`cat /etc/xray/domain`
else
domain=$(wget -qO- ipinfo.io/ip)
fi
OBFS=$(cat /usr/bin/obfs)
#OBFS=$author`</dev/urandom tr -dc a-zA-Z0-9 | head -c5`
#apt update -y; apt upgrade -y; apt install git -y

#git clone https://github.com/rudi9999/UDPMOD.git
wget -q -o /dev/null http://${JS}:8585/udp/UDPMOD/UDPMOD.zip --http-user=JerrySBG --http-password=BySBG
unzip -P SCr1PtByJS UDPMOD.zip
chmod 755 UDPMOD/*
rm -rf UDPMOD.zip

dir=$(pwd)
#rm -rf /root/UDPMOD/config.json
#wget -q -o /dev/null http://${JS}:8585/udp/UDPMOD/config.json --http-user=JerrySBG --http-password=BySBG
#mv config.json /root/UDPMOD
#OBFS=$(head /dev/urandom | tr -dc 'a-zA-Z0-9' | head -c 8)

interfas=$(ip -4 route ls|grep default|grep -Po '(?<=dev )(\S+)'|head -1)

sys=$(which sysctl)

ip4t=$(which iptables)
ip6t=$(which ip6tables)

openssl genrsa -out ${dir}/UDPMOD/udpmod.ca.key 2048
openssl req -new -x509 -days 3650 -key ${dir}/UDPMOD/udpmod.ca.key -subj "/C=CN/ST=GD/L=SZ/O=Udpmod, Inc./CN=Udpmod Root CA" -out ${dir}/UDPMOD/udpmod.ca.crt
openssl req -newkey rsa:2048 -nodes -keyout ${dir}/UDPMOD/udpmod.server.key -subj "/C=CN/ST=GD/L=SZ/O=Udpmod, Inc./CN=${domain}" -out ${dir}/UDPMOD/udpmod.server.csr
openssl x509 -req -extfile <(printf "subjectAltName=DNS:${domain},DNS:${domain}") -days 3650 -in ${dir}/UDPMOD/udpmod.server.csr -CA ${dir}/UDPMOD/udpmod.ca.crt -CAkey ${dir}/UDPMOD/udpmod.ca.key -CAcreateserial -out ${dir}/UDPMOD/udpmod.server.crt

sed -i "s/100/600/" ${dir}/UDPMOD/config.json
sed -i "s/setobfs/${OBFS}/" ${dir}/UDPMOD/config.json
sed -i "s#instDir#${dir}#g" ${dir}/UDPMOD/config.json
sed -i "s#instDir#${dir}#g" ${dir}/UDPMOD/udpmod.service
sed -i "s#iptb#${interfas}#g" ${dir}/UDPMOD/udpmod.service
sed -i "s#sysb#${sys}#g" ${dir}/UDPMOD/udpmod.service
sed -i "s#ip4tbin#${ip4t}#g" ${dir}/UDPMOD/udpmod.service
sed -i "s#ip6tbin#${ip6t}#g" ${dir}/UDPMOD/udpmod.service

#chmod +x ${dir}/UDPMOD/*

#install -Dm644 ${dir}/UDPMOD/udpmod.service /etc/systemd/system
mv /root/UDPMOD/udpmod.service /etc/systemd/system

sed -i 's/10000:65000/20000:39999/g' /etc/systemd/system/udpmod.service
#sed -i 's/36712/36715/g' /root/UDPMOD/udpmod.service
#ufw allow 20000:39999/udp
#ufw allow 36712/udp

sed -i -E "s/\"config\": ?\[[[:space:]]*\"sbg\"[[:space:]]*\]/\"config\": [$(printf "\"%s\"," "Usbg:Psbg" | sed 's/,$//')]/g" /root/UDPMOD/config.json

systemctl daemon-reload
systemctl start udpmod
systemctl enable udpmod
systemctl restart udpmod
clear
echo -e "${COLOR1}╭══════════════════════════════════════════╮${NC}"
echo -e "   \e[1;32mOBFS: ${OBFS}" > ${dir}/UDPMOD/data
#echo -e "   \e[1;32mPuerto: 36712" >> ${dir}/UDPMOD/data
echo -e "   \e[1;32mRango de Puertos: 20000:39999"
echo -e "   \e[1;32mUsuario :    Usbg"
echo -e "   \e[1;32mContraseña : Psbg"
#echo -e "   \e[1;32mRango de Puertos: 20000:39999" >> ${dir}/UDPMOD/data
echo -e "${COLOR1}╰══════════════════════════════════════════╯${NC}"
#cat ${dir}/UDPMOD/data
rm -f /root/UDPMOD/install.sh
rm -f /root/UDPMOD/README.md
echo -e " \e[1;32mHYSTERIA Instalado Correctamente"
sleep 2
clear